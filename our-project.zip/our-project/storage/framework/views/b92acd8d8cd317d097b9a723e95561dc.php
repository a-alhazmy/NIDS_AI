<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
       
    </head>
    <body >
       <h1>Hello</h1>
       <a href="<?php echo e(url('/login')); ?>">login</a>
    </body>
</html>
<?php /**PATH C:\Users\aalha\our-project\resources\views/welcome.blade.php ENDPATH**/ ?>