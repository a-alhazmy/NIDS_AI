<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
       
    </head>
    <body >
       <h1>Hello</h1>
       <a href="{{ url('/login')}}">login</a>
    </body>
</html>
