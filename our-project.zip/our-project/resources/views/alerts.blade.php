<form action="/alerts" method="POST">

    @csrf


    <div>

        <label for="title">Title</label>

        <input type="text" name="title" id="title" required>

    </div>


    <div>

        <label for="description">Description</label>

        <textarea name="description" id="description" required></textarea>

    </div>


    <div>

        <button type="submit">Create Alert</button>

    </div>

</form>
<form action="{{ route('alerts.store') }}" method="post">

    @csrf

    <div class="form-group">

        <label for="title">Title</label>

        <input type="text" name="title" id="title" class="form-control" required>

    </div>

    <div class="form-group">

        <label for="message">Message</label>

        <textarea name="message" id="message" class="form-control" required></textarea>

    </div>

    <div class="form-group">

        <label for="type">Type</label>

        <select name="type" id="type" class="form-control" required>

            <option value="info">Info</option>

            <option value="success">Success</option>

            <option value="warning">Warning</option>

            <option value="error">Error</option>

        </select>

    </div>

    <button type="submit" class="btn btn-primary">Submit</button>

</form>