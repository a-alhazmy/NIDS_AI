<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/alerts', [App\Http\Controllers\AlertController::class, 'store']);

use App\Http\Controllers\WelcomeController;
Route::get('/welcome', [WelcomeController::class, 'index'])->name('welcome');

//Route::get('/login', [App\Http\Controllers\loginController::class, 'index'])->name('login'); 

Route::get('/sign up', [App\Http\Controllers\signupController::class, 'index'])->name('sign up');
Route::post('/asignup', [App\Http\Controllers\AlertController::class, 'create']);
Route::get('/dashboard', [App\Http\Controllers\dashboardController::class, 'index'])->name('sign up');
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
